// script.js
document.addEventListener('DOMContentLoaded', () => {
    // --- DOM Elements ---
    const itemInput = document.getElementById('itemInput');
    const quantityInput = document.getElementById('quantityInput');
    const alertInput = document.getElementById('alertInput');
    const typeSelect = document.getElementById('typeSelect');
    const billCheckbox = document.getElementById('billCheckbox');
    const remarksInput = document.getElementById('remarksInput'); // *** NEW ***
    const addUpdateBtn = document.getElementById('addUpdateBtn');
    const searchInput = document.getElementById('searchInput');
    const viewStockBtn = document.getElementById('viewStockBtn');
    const lowStockBtn = document.getElementById('lowStockBtn');
    const salesReportBtn = document.getElementById('salesReportBtn');
    const purchaseReportBtn = document.getElementById('purchaseReportBtn');
    const backupBtn = document.getElementById('backupBtn');
    const dataTableBody = document.getElementById('dataTableBody');
    const tableTitle = document.getElementById('tableTitle');
    const headerCol1 = document.getElementById('headerCol1');
    const headerCol2 = document.getElementById('headerCol2');
    const headerCol3 = document.getElementById('headerCol3');
    const headerCol4 = document.getElementById('headerCol4');
    const headerCol5 = document.getElementById('headerCol5'); // *** NEW ***

    const exportStockCsvBtn = document.getElementById('exportStockCsvBtn');
    const exportSalesCsvBtn = document.getElementById('exportSalesCsvBtn');
    const exportPurchasesCsvBtn = document.getElementById('exportPurchasesCsvBtn');

    // --- Data Keys ---
    const STOCK_KEY = 'inventoryApp_stockData';
    const SALES_KEY = 'inventoryApp_salesData';
    const PURCHASE_KEY = 'inventoryApp_purchaseData';

    // --- Utility Functions --- (loadData, saveData, formatDate remain the same)
    const loadData = (key) => {
        const data = localStorage.getItem(key);
        try { return data ? JSON.parse(data) : []; }
        catch (e) { console.error(`Error parsing JSON from localStorage key "${key}":`, e); return []; }
    };
    const saveData = (key, data) => {
        try { localStorage.setItem(key, JSON.stringify(data)); }
        catch (e) { console.error(`Error saving data to localStorage key "${key}":`, e); alert(`Error saving data.`); }
    };
     const formatDate = (dateString) => {
        if (!dateString) return '';
        try {
            const d = new Date(dateString);
            return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}:${String(d.getSeconds()).padStart(2, '0')}`;
        } catch (e) { return dateString; }
    };

    // --- Display Function ---
    const displayData = (data, type) => {
        // Added headerCol5 check
        if (!dataTableBody || !tableTitle || !headerCol1 || !headerCol2 || !headerCol3 || !headerCol4 || !headerCol5) {
             console.error("One or more table elements are missing from the DOM!");
             alert("Error: Table structure is missing. Cannot display data.");
             return;
        }

        dataTableBody.innerHTML = ''; // Clear existing rows

        let col1Header = 'Item';
        let col2Header = 'Quantity';
        let col3Header = 'Info';
        let col4Header = '';
        let col5Header = ''; // *** NEW *** Header text for 5th column
        let currentTitle = 'Inventory Data';
        let showCol4 = false;
        let showCol5 = false; // *** NEW *** Flag for 5th column
        let colspanVal = 3;

        // Determine headers, title, and visibility based on view type
        if (type === 'stock' || type === 'low_stock' || type === 'search_results') {
            currentTitle = (type === 'low_stock') ? 'Low Stock Items' : (type === 'search_results' ? 'Stock Search Results' : 'Current Stock');
            col1Header = 'Item';
            col2Header = 'Quantity';
            col3Header = 'Alert Limit';
            showCol4 = false;
            showCol5 = false; // *** Hide Col 5 for stock views ***
            colspanVal = 3;
        } else if (type === 'sales' || type === 'purchases') {
            currentTitle = (type === 'sales') ? 'Sales Report' : 'Purchase Report';
            col1Header = 'Item';
            col2Header = (type === 'sales') ? 'Qty Sold' : 'Qty Purchased';
            col3Header = 'Date';
            col4Header = 'Payment Method';
            col5Header = 'Remarks'; // *** Set Col 5 header text ***
            showCol4 = true;
            showCol5 = true; // *** Show Col 5 for reports ***
            colspanVal = 5; // *** Needs 5 columns now ***
        }

        // Update DOM elements
        tableTitle.textContent = currentTitle;
        headerCol1.textContent = col1Header;
        headerCol2.textContent = col2Header;
        headerCol3.textContent = col3Header;
        headerCol4.textContent = col4Header;
        headerCol5.textContent = col5Header; // *** Update 5th header text ***
        headerCol4.style.display = showCol4 ? '' : 'none';
        headerCol5.style.display = showCol5 ? '' : 'none'; // *** Show/hide 5th header cell ***

        // Handle "No data" row
        if (!data || data.length === 0) {
            let message = "No data available.";
            if(type === 'low_stock') message = "No low stock items found.";
            if(type === 'search_results') message = "No items match your search.";
            // *** Update colspan ***
            dataTableBody.innerHTML = `<tr><td colspan="${colspanVal}">${message}</td></tr>`;
            return;
        }

        // Populate Table Rows
        data.forEach(item => {
            const row = dataTableBody.insertRow();
            row.insertCell(0).textContent = item.Item; // Col 1: Item

            if (type === 'stock' || type === 'low_stock' || type === 'search_results') {
                row.insertCell(1).textContent = item.Quantity;  // Col 2: Qty
                row.insertCell(2).textContent = item.AlertLimit; // Col 3: Alert Limit
            } else if (type === 'sales' || type === 'purchases') {
                row.insertCell(1).textContent = item.Quantity;            // Col 2: Qty
                row.insertCell(2).textContent = formatDate(item.Date);  // Col 3: Date
                row.insertCell(3).textContent = item.PaymentMethod || 'Cash'; // Col 4: Payment
                row.insertCell(4).textContent = item.Remarks || '';      // *** Col 5: Remarks ***
            }
        });
    };

    // --- Core Logic Functions ---
    // *** Modified to accept remarks ***
    const recordTransaction = (type, item, quantity, paymentMethod, remarks) => {
         const key = (type === 'Sale') ? SALES_KEY : PURCHASE_KEY;
        const transactions = loadData(key);
        transactions.push({
            Item: item,
            Quantity: quantity,
            Date: new Date().toISOString(),
            PaymentMethod: paymentMethod,
            Remarks: remarks // *** Store remarks ***
        });
        saveData(key, transactions);
    };

    const updateStock = () => {
        // Read input values
        const item = itemInput.value.trim();
        const quantityStr = quantityInput.value.trim();
        const alertLimitStr = alertInput.value.trim();
        const transType = typeSelect.value;
        const isBill = billCheckbox.checked;
        const remarks = remarksInput.value.trim(); // *** Read remarks value ***
        const paymentMethod = isBill ? 'Bill' : 'Cash';

        // Basic Input Validations
        if (!item) { alert("Item name is required."); return; }
        if (!quantityStr) { alert("Quantity is required."); return; }

        const quantity = parseInt(quantityStr, 10);
        let alertLimit = alertLimitStr ? parseInt(alertLimitStr, 10) : null;

        // Numeric Validations
        if (isNaN(quantity) || quantity <= 0) { alert("Quantity must be a positive whole number."); return; }
        if (alertLimit !== null && (isNaN(alertLimit) || alertLimit < 0)) { alert("Alert Limit must be a non-negative whole number."); return; }
        if (transType === 'Sale' && alertLimitStr.trim() !== '') { alert("Alert Limit should only be set/updated during a Purchase."); alertLimit = null; }

        // Process Stock Update
        let stockData = loadData(STOCK_KEY);
        let itemFound = false;
        let insufficientStock = false;
        let processedItemName = item;

        let updatedStockData = stockData.map(entry => {
            if (insufficientStock) return entry;

            if (entry.Item.toLowerCase() === item.toLowerCase()) {
                itemFound = true;
                processedItemName = entry.Item;

                if (transType === 'Purchase') {
                    entry.Quantity += quantity;
                    if (alertLimit !== null) { entry.AlertLimit = alertLimit; }
                    // *** Pass remarks to recordTransaction ***
                    recordTransaction('Purchase', processedItemName, quantity, paymentMethod, remarks);
                } else { // Sale
                    if (entry.Quantity >= quantity) {
                        entry.Quantity -= quantity;
                         // *** Pass remarks to recordTransaction ***
                        recordTransaction('Sale', processedItemName, quantity, paymentMethod, remarks);
                    } else {
                        alert(`Not enough stock for ${processedItemName}. Available: ${entry.Quantity}`);
                        insufficientStock = true;
                    }
                }
            }
            return entry;
        });

        if (insufficientStock) { return; } // Stop if error

        // Handle new item addition (only for Purchases)
        if (!itemFound) {
            if (transType === 'Purchase') {
                 const finalAlertLimit = (alertLimit !== null) ? alertLimit : 0;
                updatedStockData.push({ Item: item, Quantity: quantity, AlertLimit: finalAlertLimit });
                processedItemName = item;
                 // *** Pass remarks to recordTransaction ***
                recordTransaction('Purchase', processedItemName, quantity, paymentMethod, remarks);
            } else { // Sale of non-existent item
                alert(`Item '${item}' not found in stock. Cannot record sale.`);
                return;
            }
        }

        saveData(STOCK_KEY, updatedStockData);
        displayData(updatedStockData, 'stock'); // Refresh view

        // Clear input fields including remarks
        itemInput.value = '';
        quantityInput.value = '';
        alertInput.value = '';
        remarksInput.value = ''; // *** Clear remarks input ***
        billCheckbox.checked = false;
        typeSelect.value = 'Purchase';
    };

    // --- View/Report Functions --- (loadStockView, checkLowStock, searchItems remain the same)
      const loadStockView = () => {
        const stockData = loadData(STOCK_KEY);
        displayData(stockData, 'stock');
        searchInput.value = '';
    };
     const viewSalesReport = () => {
        const salesData = loadData(SALES_KEY);
        salesData.sort((a, b) => new Date(b.Date) - new Date(a.Date));
        displayData(salesData, 'sales'); // Display function now handles the 5th column
        searchInput.value = '';
    };
     const viewPurchaseReport = () => {
        const purchaseData = loadData(PURCHASE_KEY);
        purchaseData.sort((a, b) => new Date(b.Date) - new Date(a.Date));
        displayData(purchaseData, 'purchases'); // Display function now handles the 5th column
        searchInput.value = '';
    };
    const checkLowStock = () => {
        const stockData = loadData(STOCK_KEY);
        const lowStockItems = stockData.filter(item => typeof item.AlertLimit === 'number' && item.Quantity <= item.AlertLimit);
        displayData(lowStockItems, 'low_stock');
        searchInput.value = '';
    };
    const searchItems = () => {
        const searchTerm = searchInput.value.toLowerCase().trim();
        const stockData = loadData(STOCK_KEY);
        if (!searchTerm) { loadStockView(); return; }
        const filteredData = stockData.filter(item => item.Item.toLowerCase().includes(searchTerm));
        displayData(filteredData, 'search_results');
    };

    // --- Backup/Export Functions --- (downloadBackup, escapeCSV, downloadCSV remain the same)
     const downloadBackup = () => { // Backup already includes remarks as part of sales/purchase data
        const stockData = loadData(STOCK_KEY);
        const salesData = loadData(SALES_KEY);
        const purchaseData = loadData(PURCHASE_KEY);
        if (stockData.length === 0 && salesData.length === 0 && purchaseData.length === 0) { alert("No data available to backup."); return; }
        try {
            const backupData = { stock: stockData, sales: salesData, purchases: purchaseData };
            const jsonData = JSON.stringify(backupData, null, 2);
            const blob = new Blob([jsonData], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `inventory_full_backup_${new Date().toISOString().split('T')[0]}.json`;
            document.body.appendChild(a); a.click(); document.body.removeChild(a); URL.revokeObjectURL(url);
        } catch (e) { console.error("Error creating JSON backup:", e); alert("Error generating JSON backup."); }
    };
    const escapeCSV = (value) => { /* ... (same as before) ... */
        if (value === null || value === undefined) return '';
        const stringValue = String(value);
        if (stringValue.includes(',') || stringValue.includes('\n') || stringValue.includes('"')) {
            const escapedValue = stringValue.replace(/"/g, '""');
            return `"${escapedValue}"`;
        }
        return stringValue;
    };
    const downloadCSV = (dataArray, headers, filename) => { /* ... (same as before) ... */
        if (!dataArray || dataArray.length === 0) { alert("No data available to export."); return; }
        try {
            let csvContent = headers.map(escapeCSV).join(',') + '\n';
            dataArray.forEach(rowArray => { csvContent += rowArray.map(escapeCSV).join(',') + '\n'; });
            const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url; a.download = filename; document.body.appendChild(a); a.click(); document.body.removeChild(a); URL.revokeObjectURL(url);
        } catch (e) { console.error("Error creating CSV:", e); alert("Error generating CSV."); }
    };

    // *** Modified CSV Exports ***
    const exportStockToCSV = () => {
        const stockData = loadData(STOCK_KEY);
        const headers = ["Item Name", "Current Quantity", "Alert Limit"];
        const dataToExport = stockData.map(item => [ item.Item, item.Quantity, item.AlertLimit ]);
        const filename = `stock_report_${new Date().toISOString().split('T')[0]}.csv`;
        downloadCSV(dataToExport, headers, filename);
    };
    const exportSalesToCSV = () => {
        const salesData = loadData(SALES_KEY);
        salesData.sort((a, b) => new Date(b.Date) - new Date(a.Date));
        // *** Add Remarks header ***
        const headers = ["Transaction Date", "Item Name", "Quantity Sold", "Payment Method", "Remarks"];
        const dataToExport = salesData.map(sale => [
            formatDate(sale.Date),
            sale.Item,
            sale.Quantity,
            sale.PaymentMethod || 'Cash',
            sale.Remarks || '' // *** Add remarks data ***
        ]);
        const filename = `sales_report_${new Date().toISOString().split('T')[0]}.csv`;
        downloadCSV(dataToExport, headers, filename);
    };
    const exportPurchasesToCSV = () => {
        const purchaseData = loadData(PURCHASE_KEY);
        purchaseData.sort((a, b) => new Date(b.Date) - new Date(a.Date));
         // *** Add Remarks header ***
        const headers = ["Transaction Date", "Item Name", "Quantity Purchased", "Payment Method", "Remarks"];
        const dataToExport = purchaseData.map(purchase => [
            formatDate(purchase.Date),
            purchase.Item,
            purchase.Quantity,
            purchase.PaymentMethod || 'Cash',
            purchase.Remarks || '' // *** Add remarks data ***
        ]);
        const filename = `purchase_report_${new Date().toISOString().split('T')[0]}.csv`;
        downloadCSV(dataToExport, headers, filename);
    };

    // --- Event Listeners ---
    if (addUpdateBtn) addUpdateBtn.addEventListener('click', updateStock);
    if (viewStockBtn) viewStockBtn.addEventListener('click', loadStockView);
    if (salesReportBtn) salesReportBtn.addEventListener('click', viewSalesReport);
    if (purchaseReportBtn) purchaseReportBtn.addEventListener('click', viewPurchaseReport);
    if (lowStockBtn) lowStockBtn.addEventListener('click', checkLowStock);
    if (searchInput) searchInput.addEventListener('input', searchItems);
    if (backupBtn) backupBtn.addEventListener('click', downloadBackup);
    if (exportStockCsvBtn) exportStockCsvBtn.addEventListener('click', exportStockToCSV);
    if (exportSalesCsvBtn) exportSalesCsvBtn.addEventListener('click', exportSalesToCSV);
    if (exportPurchasesCsvBtn) exportPurchasesCsvBtn.addEventListener('click', exportPurchasesToCSV);

    // --- Initial Load ---
    loadStockView(); // Display the current stock list when the page loads

}); // End of DOMContentLoaded listener